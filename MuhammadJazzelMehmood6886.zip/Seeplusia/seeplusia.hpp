#include<iostream>
#include<string>
using namespace std;

extern int applesLeft, nCrystalsFound;
extern string gameState;

void makeMove(string direction);
